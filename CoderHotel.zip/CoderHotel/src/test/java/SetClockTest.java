import static org.junit.Assert.*;

import java.text.SimpleDateFormat;

import org.junit.Assert;
import org.junit.Test;


public class SetClockTest {


	
	@Test
	public void testLondonClock() {
		LondonClock clock = new LondonClock();
		clock.setTime(2019, 3, 25, 23, 56, 56);
		assertEquals("London", clock.city);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		assertEquals("2019-03-25 23:56:56",sdf.format(clock.getTime()));
	}
	
	@Test
	public void testBeijingClock() {
		BeijingClock clock = new BeijingClock();
		clock.setTime(2019, 3, 25, 23, 56, 56);
		assertEquals("Beijing", clock.city);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		assertEquals("2019-03-26 07:56:56",sdf.format(clock.getTime()));
	}
	
	@Test
	public void testMoscowClock() {
		MoscowClock clock = new MoscowClock();
		clock.setTime(2019, 3, 25, 23, 56, 56);
		assertEquals("Moscow", clock.city);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		assertEquals("2019-03-26 03:56:56",sdf.format(clock.getTime()));
	}
	
	@Test
	public void testNewYorkClock() {
		NewYorkClock clock = new NewYorkClock();
		clock.setTime(2019, 3, 25, 23, 56, 56);
		assertEquals("NewYork", clock.city);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		assertEquals("2019-03-25 18:56:56",sdf.format(clock.getTime()));
	}
	
	@Test
	public void testSydneyClock() {
		SydneyClock clock = new SydneyClock();
		clock.setTime(2019, 3, 25, 23, 56, 56);
		assertEquals("Sydney", clock.city);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		assertEquals("2019-03-26 09:56:56",sdf.format(clock.getTime()));
	}
	
	@Test
	public void testIntelligentPhone() {
		IntelligentPhone ip = new IntelligentPhone(2019,11,14,20,05,00);
		ip.setTime();
		ip.setAllTime();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		assertEquals("London",ip.lClock.city);
		assertEquals("Beijing",ip.bClock.city);
		assertEquals("Moscow",ip.mClock.city);
		assertEquals("NewYork",ip.nyClock.city);
		assertEquals("Sydney",ip.sClock.city);
		assertEquals("2019-11-14 20:05:00",sdf.format(ip.lClock.getTime()));
		assertEquals("2019-11-15 04:05:00",sdf.format(ip.bClock.getTime()));
		assertEquals("2019-11-15 00:05:00",sdf.format(ip.mClock.getTime()));
		assertEquals("2019-11-14 15:05:00",sdf.format(ip.nyClock.getTime()));
		assertEquals("2019-11-15 06:05:00",sdf.format(ip.sClock.getTime()));
		assertEquals("2019-11-15 04:05:00",sdf.format(ip.getTime()));
	}

}
