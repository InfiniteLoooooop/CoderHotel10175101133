
public class MoscowClock extends Clock {

	public MoscowClock() {
		this.city = "Moscow";
		this.dateDifference = 4;
	}

}
