import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class IntelligentPhone {

	public int dateDifference = 8;
	public Date standardTime;
	public int year;
	public int month;
	public int day;
	public int hour;
	public int minute;
	public int second;
	LondonClock lClock = new LondonClock();
	BeijingClock bClock = new BeijingClock();
	MoscowClock mClock = new MoscowClock();
	NewYorkClock nyClock = new NewYorkClock();
	SydneyClock sClock = new SydneyClock();
	
	public IntelligentPhone(int curYear, int curMonth, int curDay, int curHour, int curMinute, int curSecond)
	{
		year = curYear;
		month = curMonth;
		day = curDay;
		hour = curHour;
		minute = curMinute;
		second = curSecond;
	}
	
	public void print()
	{
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		System.out.println("Intelligent Phone Time in Beijing " + sdf.format(this.getTime()));
	}
	
	public Date getTime()
	{
		Calendar c = Calendar.getInstance();
		c.setTime(this.standardTime);
		c.add(Calendar.HOUR, dateDifference);
		Date cityDate = c.getTime();
		return cityDate;
	}
	
	public void setTime()
	{
		Calendar cal = Calendar.getInstance();
		cal.set(Calendar.YEAR, this.year);
		cal.set(Calendar.MONTH, this.month - 1);
		cal.set(Calendar.DAY_OF_MONTH, this.day);
		cal.set(Calendar.HOUR_OF_DAY, this.hour);
		cal.set(Calendar.MINUTE, this.minute);
		cal.set(Calendar.SECOND, this.second);
		standardTime = cal.getTime();
	}
	
	public void setAllTime()
	{
		lClock.setTime(this.year,this.month,this.day,this.hour,this.minute,this.second);
		bClock.setTime(this.year,this.month,this.day,this.hour,this.minute,this.second);
		mClock.setTime(this.year,this.month,this.day,this.hour,this.minute,this.second);
		nyClock.setTime(this.year,this.month,this.day,this.hour,this.minute,this.second);
		sClock.setTime(this.year,this.month,this.day,this.hour,this.minute,this.second);
		
	}
	
	public void printAll()
	{
		this.print();
		lClock.print();
		bClock.print();
		mClock.print();
		nyClock.print();
		sClock.print();
	}

}
