public class SetClock {

	public static void main(String args[])
	{
		IntelligentPhone ip = new IntelligentPhone(2019,11,14,20,05,00);
		ip.setTime();
		ip.setAllTime();
		ip.printAll();
	}

}
