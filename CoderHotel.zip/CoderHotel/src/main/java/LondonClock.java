
public class LondonClock extends Clock {
	public LondonClock()
	{
		this.city = "London";
		this.dateDifference = 0;
	}

}
