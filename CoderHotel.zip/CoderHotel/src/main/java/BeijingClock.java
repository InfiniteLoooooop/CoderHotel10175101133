
public class BeijingClock extends Clock {

	public BeijingClock()
	{
		this.city = "Beijing";
		this.dateDifference = 8;
	}
	
}
