
public class SydneyClock extends Clock{

	public SydneyClock() {
		this.city = "Sydney";
		this.dateDifference = 10;
	}

}
