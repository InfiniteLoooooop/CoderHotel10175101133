
public class NewYorkClock extends Clock {

	public NewYorkClock() {
		this.city = "NewYork";
		this.dateDifference = -5;
	}

}
